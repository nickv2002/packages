# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_imgcompress_global_optspecs
    string join \n h/help V/version
end

function __fish_imgcompress_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_imgcompress_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_imgcompress_using_subcommand
    set -l cmd (__fish_imgcompress_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c imgcompress -n "__fish_imgcompress_needs_command" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -s V -l version -d 'Print version'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "run" -d 'Headless processing'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "open" -d 'Hand paths to the Mac app (macOS only)'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "undo" -d 'Revert one finished job from its `undo` record (a JSON file)'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "preview" -d 'Encode one file with the effective options and report the size'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "score" -d 'How close a compressed image looks to the original (SSIMULACRA2: 100 = identical, 88 and up = visually lossless)'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "presets" -d 'Manage presets (one JSON file each in the Presets folder)'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "options" -d 'Options model'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "tools" -d 'List linked encoders and helpers'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "history" -d 'Processing history'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "licenses" -d 'Print license notices'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "completions" -d 'Print shell completions'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "man" -d 'Print the man page'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "install" -d 'Symlink this executable into a directory on PATH'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "uninstall" -d 'Remove the symlink made by `install`'
complete -c imgcompress -n "__fish_imgcompress_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l preset -d 'Start from a preset: its id or name, or the path of a preset file' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l options-file -d 'JSON file with (partial) options, applied after --preset' -r -F
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l save-preset -d 'Save the effective options as a preset' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l min-size -d 'Skip inputs smaller than this, e.g. 10KB, 2MB, 500' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l format -d 'keep|jpeg|png|webp|heic|avif|jxl' -r -f -a "keep\t''
jpeg\t''
png\t''
webp\t''
heic\t''
avif\t''
jxl\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l destination -d 'in-place, alongside (adds the suffix), or an output directory' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l suffix -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l originals -r -f -a "keep\t''
trash\t''
delete\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l replace-if -d 'Keep a result only if it is smaller, also when it is converted to another format, or always' -r -f -a "smaller\t''
smaller-or-converted\t''
always\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l overwrite -d 'What to do when the output name is taken by a file that is not the input itself' -r -f -a "skip\t''
rename\t''
replace\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l metadata -r -f -a "none\t''
icc\t''
exif-no-gps\t''
all\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l quality -d 'Shortcut: 1-100 or "lossless", applied to the encoder --format selects (JPEG and PNG when format is keep)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jpeg-encoder -r -f -a "jpegli\t''
mozjpeg\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jpeg-quality -d '1-100 or "lossless" (a reversible repack, so JPEG input only: other images are skipped)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jpeg-subsampling -r -f -a "auto\t''
444\t''
422\t''
420\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l png-quantize -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l png-quantize-speed -d '1-11' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l png-optimize-level -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l png-zopfli -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jxl-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jxl-effort -d '1-10' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l avif-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l avif-alpha-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l avif-speed -d '0-10' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l avif-depth -r -f -a "8\t''
10\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l heic-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l heic-depth -r -f -a "8\t''
10\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l webp-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l webp-method -d '0-6' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l webp-alpha-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l gif-optimize-level -d '1-3' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l gif-lossy -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l svg-precision -d '0-5 decimal places kept in SVG numbers and paths' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l svg-max-size -d 'Skip SVGs larger than this, e.g. 500KB, 2MB (0 = no limit)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l target-quality -d 'Target SSIMULACRA2 score (e.g. 70) or "off": per-image search of the lossy quality (JPEG, WebP, AVIF, JXL)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l target-tolerance -d 'Accept results scoring in [target, target+N]' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l max-encodes -d 'Maximum encodes per image for --target-quality' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l max-dimension -d 'Downscale so the longer side is at most PX (never upscales)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l scale -d 'Downscale to PERCENT of the original size (1-99)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l anim-to -d 'Animated GIF/APNG/WebP/AVIF output: keep (optimise in place), webp or avif (animated)' -r -f -a "keep\t''
webp\t''
avif\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jobs -d 'Worker count (0 = all cores)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l backup-dir -d 'Keep a backup of every file this run replaces or removes in DIR, and put an `undo` record in each finished event' -r -F
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l recursive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-recursive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l include-hidden
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l preserve-dates
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-preserve-dates
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jpeg-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-jpeg-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l png-dither
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-png-dither
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jxl-jpeg-transcode
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-jxl-jpeg-transcode
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l jxl-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-jxl-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l svg-aggressive -d 'Also run cleanupIds/convertTransform/applyTransforms (renames ids; still render-checked)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-svg-aggressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l compact-icc -d 'Drop sRGB-equivalent ICC profiles (default)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-compact-icc
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l strip-previews -d 'Remove EXIF thumbnails, MPF previews and APP13'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l convert-to-srgb -d 'Convert non-sRGB (e.g. Display P3) pixels to sRGB and drop the profile'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l history
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l no-history
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l dry-run -d 'Print the plan, change nothing'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -l json -d 'NDJSON events on stdout'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -s q -l quiet
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -s v -l verbose
complete -c imgcompress -n "__fish_imgcompress_using_subcommand run" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l preset -d 'Start from a preset: its id or name, or the path of a preset file' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l options-file -d 'JSON file with (partial) options, applied after --preset' -r -F
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l save-preset -d 'Save the effective options as a preset' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l min-size -d 'Skip inputs smaller than this, e.g. 10KB, 2MB, 500' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l format -d 'keep|jpeg|png|webp|heic|avif|jxl' -r -f -a "keep\t''
jpeg\t''
png\t''
webp\t''
heic\t''
avif\t''
jxl\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l destination -d 'in-place, alongside (adds the suffix), or an output directory' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l suffix -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l originals -r -f -a "keep\t''
trash\t''
delete\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l replace-if -d 'Keep a result only if it is smaller, also when it is converted to another format, or always' -r -f -a "smaller\t''
smaller-or-converted\t''
always\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l overwrite -d 'What to do when the output name is taken by a file that is not the input itself' -r -f -a "skip\t''
rename\t''
replace\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l metadata -r -f -a "none\t''
icc\t''
exif-no-gps\t''
all\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l quality -d 'Shortcut: 1-100 or "lossless", applied to the encoder --format selects (JPEG and PNG when format is keep)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jpeg-encoder -r -f -a "jpegli\t''
mozjpeg\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jpeg-quality -d '1-100 or "lossless" (a reversible repack, so JPEG input only: other images are skipped)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jpeg-subsampling -r -f -a "auto\t''
444\t''
422\t''
420\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l png-quantize -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l png-quantize-speed -d '1-11' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l png-optimize-level -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l png-zopfli -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jxl-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jxl-effort -d '1-10' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l avif-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l avif-alpha-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l avif-speed -d '0-10' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l avif-depth -r -f -a "8\t''
10\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l heic-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l heic-depth -r -f -a "8\t''
10\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l webp-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l webp-method -d '0-6' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l webp-alpha-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l gif-optimize-level -d '1-3' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l gif-lossy -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l svg-precision -d '0-5 decimal places kept in SVG numbers and paths' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l svg-max-size -d 'Skip SVGs larger than this, e.g. 500KB, 2MB (0 = no limit)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l target-quality -d 'Target SSIMULACRA2 score (e.g. 70) or "off": per-image search of the lossy quality (JPEG, WebP, AVIF, JXL)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l target-tolerance -d 'Accept results scoring in [target, target+N]' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l max-encodes -d 'Maximum encodes per image for --target-quality' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l max-dimension -d 'Downscale so the longer side is at most PX (never upscales)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l scale -d 'Downscale to PERCENT of the original size (1-99)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l anim-to -d 'Animated GIF/APNG/WebP/AVIF output: keep (optimise in place), webp or avif (animated)' -r -f -a "keep\t''
webp\t''
avif\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jobs -d 'Worker count (0 = all cores)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l start -d 'Start processing immediately'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l recursive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-recursive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l include-hidden
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l preserve-dates
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-preserve-dates
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jpeg-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-jpeg-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l png-dither
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-png-dither
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jxl-jpeg-transcode
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-jxl-jpeg-transcode
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l jxl-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-jxl-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l svg-aggressive -d 'Also run cleanupIds/convertTransform/applyTransforms (renames ids; still render-checked)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-svg-aggressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l compact-icc -d 'Drop sRGB-equivalent ICC profiles (default)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-compact-icc
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l strip-previews -d 'Remove EXIF thumbnails, MPF previews and APP13'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l convert-to-srgb -d 'Convert non-sRGB (e.g. Display P3) pixels to sRGB and drop the profile'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l history
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l no-history
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -l dry-run -d 'Print the plan, change nothing'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand open" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand undo" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l out -r -F
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l preset -d 'Start from a preset: its id or name, or the path of a preset file' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l options-file -d 'JSON file with (partial) options, applied after --preset' -r -F
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l save-preset -d 'Save the effective options as a preset' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l min-size -d 'Skip inputs smaller than this, e.g. 10KB, 2MB, 500' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l format -d 'keep|jpeg|png|webp|heic|avif|jxl' -r -f -a "keep\t''
jpeg\t''
png\t''
webp\t''
heic\t''
avif\t''
jxl\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l destination -d 'in-place, alongside (adds the suffix), or an output directory' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l suffix -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l originals -r -f -a "keep\t''
trash\t''
delete\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l replace-if -d 'Keep a result only if it is smaller, also when it is converted to another format, or always' -r -f -a "smaller\t''
smaller-or-converted\t''
always\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l overwrite -d 'What to do when the output name is taken by a file that is not the input itself' -r -f -a "skip\t''
rename\t''
replace\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l metadata -r -f -a "none\t''
icc\t''
exif-no-gps\t''
all\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l quality -d 'Shortcut: 1-100 or "lossless", applied to the encoder --format selects (JPEG and PNG when format is keep)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jpeg-encoder -r -f -a "jpegli\t''
mozjpeg\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jpeg-quality -d '1-100 or "lossless" (a reversible repack, so JPEG input only: other images are skipped)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jpeg-subsampling -r -f -a "auto\t''
444\t''
422\t''
420\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l png-quantize -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l png-quantize-speed -d '1-11' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l png-optimize-level -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l png-zopfli -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jxl-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jxl-effort -d '1-10' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l avif-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l avif-alpha-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l avif-speed -d '0-10' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l avif-depth -r -f -a "8\t''
10\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l heic-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l heic-depth -r -f -a "8\t''
10\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l webp-quality -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l webp-method -d '0-6' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l webp-alpha-quality -d '1-100' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l gif-optimize-level -d '1-3' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l gif-lossy -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l svg-precision -d '0-5 decimal places kept in SVG numbers and paths' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l svg-max-size -d 'Skip SVGs larger than this, e.g. 500KB, 2MB (0 = no limit)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l target-quality -d 'Target SSIMULACRA2 score (e.g. 70) or "off": per-image search of the lossy quality (JPEG, WebP, AVIF, JXL)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l target-tolerance -d 'Accept results scoring in [target, target+N]' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l max-encodes -d 'Maximum encodes per image for --target-quality' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l max-dimension -d 'Downscale so the longer side is at most PX (never upscales)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l scale -d 'Downscale to PERCENT of the original size (1-99)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l anim-to -d 'Animated GIF/APNG/WebP/AVIF output: keep (optimise in place), webp or avif (animated)' -r -f -a "keep\t''
webp\t''
avif\t''"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jobs -d 'Worker count (0 = all cores)' -r
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l recursive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-recursive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l include-hidden
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l preserve-dates
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-preserve-dates
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jpeg-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-jpeg-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l png-dither
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-png-dither
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jxl-jpeg-transcode
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-jxl-jpeg-transcode
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l jxl-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-jxl-progressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l svg-aggressive -d 'Also run cleanupIds/convertTransform/applyTransforms (renames ids; still render-checked)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-svg-aggressive
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l compact-icc -d 'Drop sRGB-equivalent ICC profiles (default)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-compact-icc
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l strip-previews -d 'Remove EXIF thumbnails, MPF previews and APP13'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l convert-to-srgb -d 'Convert non-sRGB (e.g. Display P3) pixels to sRGB and drop the profile'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l history
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l no-history
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -l dry-run -d 'Print the plan, change nothing'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand preview" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand score" -l json
complete -c imgcompress -n "__fish_imgcompress_using_subcommand score" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -f -a "list"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -f -a "show" -d 'Print a preset with all options expanded'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -f -a "export" -d 'Print one preset as a shareable file, or all of them as one bundle'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -f -a "import" -d 'Copy preset files (or an exported bundle) into the Presets folder'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -f -a "delete"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -f -a "reset" -d 'Restore the built-in presets (keeps custom ones unless --all)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -f -a "path" -d 'Print the Presets folder'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and not __fish_seen_subcommand_from list show export import delete reset path help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from list" -l json
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from list" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from export" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from import" -l force -d 'Replace a preset with the same name'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from import" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from delete" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from reset" -l all
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from reset" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from path" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from help" -f -a "list"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from help" -f -a "show" -d 'Print a preset with all options expanded'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from help" -f -a "export" -d 'Print one preset as a shareable file, or all of them as one bundle'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from help" -f -a "import" -d 'Copy preset files (or an exported bundle) into the Presets folder'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from help" -f -a "delete"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from help" -f -a "reset" -d 'Restore the built-in presets (keeps custom ones unless --all)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from help" -f -a "path" -d 'Print the Presets folder'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand presets; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand options; and not __fish_seen_subcommand_from schema help" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand options; and not __fish_seen_subcommand_from schema help" -f -a "schema" -d 'Print the JSON Schema of Options'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand options; and not __fish_seen_subcommand_from schema help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand options; and __fish_seen_subcommand_from schema" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand options; and __fish_seen_subcommand_from help" -f -a "schema" -d 'Print the JSON Schema of Options'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand options; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand tools" -l check -d 'Exit 3 if a required encoder or helper is missing'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand tools" -l json
complete -c imgcompress -n "__fish_imgcompress_using_subcommand tools" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and not __fish_seen_subcommand_from stats clear help" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and not __fish_seen_subcommand_from stats clear help" -f -a "stats"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and not __fish_seen_subcommand_from stats clear help" -f -a "clear"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and not __fish_seen_subcommand_from stats clear help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and __fish_seen_subcommand_from stats" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and __fish_seen_subcommand_from clear" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and __fish_seen_subcommand_from help" -f -a "stats"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and __fish_seen_subcommand_from help" -f -a "clear"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand history; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand licenses" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand completions" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand man" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand install" -l dir -r -F
complete -c imgcompress -n "__fish_imgcompress_using_subcommand install" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand uninstall" -l dir -r -F
complete -c imgcompress -n "__fish_imgcompress_using_subcommand uninstall" -s h -l help -d 'Print help'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "run" -d 'Headless processing'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "open" -d 'Hand paths to the Mac app (macOS only)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "undo" -d 'Revert one finished job from its `undo` record (a JSON file)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "preview" -d 'Encode one file with the effective options and report the size'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "score" -d 'How close a compressed image looks to the original (SSIMULACRA2: 100 = identical, 88 and up = visually lossless)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "presets" -d 'Manage presets (one JSON file each in the Presets folder)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "options" -d 'Options model'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "tools" -d 'List linked encoders and helpers'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "history" -d 'Processing history'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "licenses" -d 'Print license notices'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "completions" -d 'Print shell completions'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "man" -d 'Print the man page'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "install" -d 'Symlink this executable into a directory on PATH'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "uninstall" -d 'Remove the symlink made by `install`'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and not __fish_seen_subcommand_from run open undo preview score presets options tools history licenses completions man install uninstall help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from presets" -f -a "list"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from presets" -f -a "show" -d 'Print a preset with all options expanded'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from presets" -f -a "export" -d 'Print one preset as a shareable file, or all of them as one bundle'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from presets" -f -a "import" -d 'Copy preset files (or an exported bundle) into the Presets folder'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from presets" -f -a "delete"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from presets" -f -a "reset" -d 'Restore the built-in presets (keeps custom ones unless --all)'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from presets" -f -a "path" -d 'Print the Presets folder'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from options" -f -a "schema" -d 'Print the JSON Schema of Options'
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from history" -f -a "stats"
complete -c imgcompress -n "__fish_imgcompress_using_subcommand help; and __fish_seen_subcommand_from history" -f -a "clear"
